# Phase 05 — Admin UI + AuditSignal Schema

## What's in this archive

### `ui/` — React Admin Terminal

Production replacement for `NCAOS_UI_final.html`.

**Start:**
```bash
# From egs/ root — API must be running first
cd api && npm start          # Terminal 1: API on port 3000
cd ui && npm install && npm run dev   # Terminal 2: UI on port 5173
```

Open `http://localhost:5173`

**Four role-based views:**

| Role | Focus |
|---|---|
| SOC OPERATOR | Event log, active containment, MTTD SLA, routing |
| ARCHITECT | Shell integrity, continuity state, detection layer MTTD |
| AUDITOR | Evidence trail, sequence analysis, policy, event stats |
| EXECUTIVE | RAW vs GOVERNED chart, integrity trend, system status |

**Live data:** WebSocket connection to `/v1/state/stream` for real-time
GovState updates. TanStack Query polls all other endpoints with configurable
intervals.

**Key feature — Sequence Analysis (Toru-William):**
In the Auditor view, clicking an evidence handle that has a `sequenceId`
loads the full sequence panel showing:
- Event chain visualization (DOWNGRADE→BLOCK chain)
- `patternType`: STABLE / DEGRADING / CONTAINED / VOLATILE / UNKNOWN
- `escalationDetected`: whether severity increased over sequence
- `consistencyScore`: 0–100 enforcement consistency

---

### `audit-signal/` — Formal AuditSignal Schema

The typed contract between NCAOS EGS and the Urielle audit layer.
See ADR-006 for rationale.

**Usage in Urielle:**
```typescript
import { AuditSignalSchema, fromEventRecord, evidenceLevel, auditFindingSummary, ISO42001_CONTROL_MAP } from '@ncaos/audit-signal';

// Fetch from NCAOS API
const record = await fetch('/v1/audit/EVD-...');
const signal = fromEventRecord(record, sequenceSummary, enrichment);

// Validate
AuditSignalSchema.parse(signal); // throws if invalid

// Generate audit evidence
const level = evidenceLevel(signal);        // 'STRONG' | 'MODERATE' | 'WEAK'
const finding = auditFindingSummary(signal); // human-readable finding
const controls = ISO42001_CONTROL_MAP[signal.core.layer]; // ISO 42001 refs
```

**Three layers:**
- `core` — always present (14 fields, minimum viable signal layer)
- `sequence` — present when workflowId provided (behavioral patterns)
- `enrichment` — optional (identity, asset, session references)

---

### `docs/adr/ADR-006-audit-signal-schema.md`

Architecture Decision Record formalizing the Urielle interface contract.

## Installation

```powershell
cd C:\AI Project\NCAOS-Urielle

tar -xzf ncaos-phase05.tar.gz

# Copy UI package into egs/
Copy-Item -Recurse phase05\ui egs\ui

# Copy audit-signal package
Copy-Item -Recurse phase05\audit-signal egs\audit-signal

# Add ADR-006
Copy-Item phase05\docs\adr\ADR-006-audit-signal-schema.md egs\docs\adr\

# Add ui and audit-signal to egs/package.json workspaces array
# "workspaces": ["core", "shell", "api", "detection", "ui", "audit-signal"]

cd egs
npm install

# Start API (Terminal 1)
cd api && npm start

# Start UI (Terminal 2)
cd ../ui && npm run dev
```
