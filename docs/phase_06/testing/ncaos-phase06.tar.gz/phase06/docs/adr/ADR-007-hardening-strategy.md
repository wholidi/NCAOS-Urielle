# ADR-007: Phase 06 Security Hardening Strategy

**Date:** 2026-05-14
**Status:** Accepted
**Authors:** MLP / NCAOS Architecture

---

## Context

Phase 05 completed the Admin Terminal and AuditSignal schema. Before the
stakeholder demo (Phase 07), the system requires a formal security review.
Phase 06 addresses three areas:

1. **Threat modeling** — STRIDE + AI/ML threat analysis
2. **Security fixes** — JWT auth, RBAC, rate limiting
3. **Compliance mapping** — ISO 42001:2023 control coverage

## Decisions

### Decision 1: JWT in Dev-Optional Mode

JWT authentication is implemented in `auth-middleware.ts` but activated
only when `JWT_SECRET` environment variable is set. This preserves
Phase 02–05 API compatibility during development while providing a
production-ready security path.

When `JWT_SECRET` is unset (dev mode):
- X-Partner-ID header accepted without verification (Phase 02–05 behavior)
- All RBAC roles defaulted to 'operator'
- S-001 residual risk documented as accepted in dev

When `JWT_SECRET` is set (production mode):
- Bearer JWT required in Authorization header
- X-Partner-ID must match JWT sub claim
- RBAC enforced per route

### Decision 2: Rate Limiting as In-Memory Token Bucket

The `RateLimiter` uses an in-memory token bucket (100 req/s, burst 150)
per PARTNER_ID. This is sufficient for single-node deployments.

Phase 07 upgrade path: Replace with Redis-backed sliding window counter
for multi-node consistency.

### Decision 3: ISO 42001 Coverage Target

Phase 06 targets ≥70% ISO 42001 coverage (implemented + 50% of partial).
Remaining gaps are documented as Phase 07 scope:
- Full JWT deployment (A.6.1 partial → implemented)
- Historical trend persistence (10.2 partial → implemented)
- Cross-session audit persistence (TimescaleDB)

### Decision 4: Pen Tests Are Manual + Automated

PT-001 through PT-010 include PowerShell commands for manual execution.
The chaos test (PT-CHAOS-001) requires manual shell process termination.
Automated equivalents (mttd-regression.test.ts) validate SLA baselines.

## STRIDE Risk Register Summary

| Risk Level | Count | Phase 06 Action |
|---|---|---|
| HIGH | 3 | JWT middleware, RBAC for policy, rate limiter |
| MED | 8 | Documented, mitigated where feasible |
| LOW | 4 | Accepted |

HIGH risks mitigated in Phase 06:
- S-001: JWT + sub claim validation
- T-002/E-001: RBAC — POST /v1/policy requires admin role
- D-001: Rate limiter 100 req/s per tenant

## Consequences

1. Existing tests (181 automated) are unaffected — JWT is opt-in
2. Phase 07 demo will run without JWT (dev mode) for simplicity
3. ISO 42001 coverage ≥70% is sufficient for concept demonstration
4. Commercial deployment requires JWT_SECRET + Redis rate limiter
