// ── SEQUENCE ROUTES TO ADD TO server.ts ────────────────────────────────────
// Insert these two routes before the WS /v1/state/stream route

// GET /v1/events/sequence/:sequenceId — all events in a workflow sequence
// GET /v1/events/sequence/:sequenceId/summary — behavioral pattern summary
