# Phase 07 — Stakeholder Demo & Handoff

## What's in this archive

### `demo/demo-scenario.ts`
Structured demo script — 6 steps across 4 stakeholder audiences.
Run steps D-01 through D-06 in sequence with the API server running.

### `pilot/pilot-proposal.ts`
Three-tier commercial pilot structure (Observe → Contain → Audit).
v1.0 roadmap with MUST/SHOULD/NICE priority items and STRIDE refs.

### `docs/adr/ADR-008-v1-roadmap.md`
Architecture decision record for v1.0-rc scope.

## Demo Setup

```powershell
# Terminal 1 — API
cd "D:\Projects\NCAOS-Urielle\egs\api"
npm start

# Terminal 2 — UI
cd "D:\Projects\NCAOS-Urielle\egs\ui"
npm run dev
# Open http://localhost:5173

# Terminal 3 — Demo commands (from demo-scenario.ts)
```

## Git Tag

```powershell
git tag -a v1.0-rc -m "v1.0-rc — EGS complete — Phases 01-07"
git push origin v1.0-rc
```
